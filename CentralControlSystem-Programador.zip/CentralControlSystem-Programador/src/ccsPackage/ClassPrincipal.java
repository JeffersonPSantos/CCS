package ccsPackage;

import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * @author Alyph
 */

public class ClassPrincipal extends Application
{

    /**
     *
     * @param primaryStage
     */
    @Override
    public void start(Stage primaryStage) 
    {
         
    }
     
    public static void main(String[] args) 
    {
        
    FrameMenu frameMenu = new FrameMenu();
    frameMenu.setVisible(true);
    
             
    }
}
